float pos_power(float, int);

