
float max(float, float);
float min(float, float);

