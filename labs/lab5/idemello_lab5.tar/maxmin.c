
float max(float num1, float num2)
{
   if(num1>num2)
   return num1;
   else{return num2;}

}
float min(float num1, float num2)
{
   if(num1<num2)
   return num1;
   else{return num2;}
}
