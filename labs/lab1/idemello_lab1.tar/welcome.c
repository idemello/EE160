
/*     File : welcome.c     *
 *     By   : Isaac DeMello  *
 *     login: idemello              *
 *     Date : 1/21/15              */

/* 
   A simple program that prints a welcoming message.
*/

#include <stdio.h>

int main()
{
  printf("Welcome to EE160!\n");

}
