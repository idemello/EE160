/*     File : myinfo.c       *
 *     By   : Isaac DeMello  *
 *     login: idemello       *
 *     Date : Jan 21 2016    */

/* 
   A program you need to modify to print your full name.
*/


int main()
{
  printf("My name is: Isaac DeMello\n");
  printf("My E-mail is: idemello@hawaii.edu\n");
}

