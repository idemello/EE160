void reorder(float *a, float *b, float *c);
