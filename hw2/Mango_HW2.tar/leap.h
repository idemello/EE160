int is_leap(int);     

#define TRUE 1
#define FALSE 0
