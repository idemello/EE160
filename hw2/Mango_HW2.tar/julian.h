int julian_date(int, int, int);

#define TRUE 1
#define FALSE 0
