int days_in_month(int month, int year);

#define TRUE 1
#define FALSE 0
